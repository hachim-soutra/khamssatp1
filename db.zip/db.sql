-- --------------------------------------------------------
-- Hôte :                        localhost
-- Version du serveur:           5.7.24 - MySQL Community Server (GPL)
-- SE du serveur:                Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Listage de la structure de la base pour khamsat_p1
CREATE DATABASE IF NOT EXISTS `khamsat_p1` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `khamsat_p1`;

-- Listage de la structure de la table khamsat_p1. failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Listage des données de la table khamsat_p1.failed_jobs : ~0 rows (environ)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Listage de la structure de la table khamsat_p1. migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Listage des données de la table khamsat_p1.migrations : ~3 rows (environ)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_10_12_000000_create_users_table', 1),
	(2, '2019_08_19_000000_create_failed_jobs_table', 1),
	(3, '2020_05_30_005307_create_posts_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Listage de la structure de la table khamsat_p1. posts
CREATE TABLE IF NOT EXISTS `posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `is_publish` int(11) NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lien` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Listage des données de la table khamsat_p1.posts : ~22 rows (environ)
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` (`id`, `user_id`, `view`, `is_publish`, `content`, `description`, `img`, `type`, `lien`, `created_at`, `updated_at`) VALUES
	(1, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(2, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(3, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(4, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(5, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(6, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(7, 9, 16, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(8, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(9, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(10, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(11, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(12, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(13, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(14, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:46:12'),
	(15, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(16, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(17, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(18, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(19, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(20, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(21, 9, 15, 1, 'dddddddddddddddd', 'dddddddddddddddd', 'Nan', 'video', 'c0swtYusRKs', '2020-05-31 13:59:12', '2020-05-31 16:47:48'),
	(22, 10, 2, 1, 'لللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللل', 'لللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللللل', '1590943571.jpg', 'post', 'https://khamsat.com/order/1610052', '2020-05-31 16:46:11', '2020-05-31 16:47:48');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;

-- Listage de la structure de la table khamsat_p1. users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Listage des données de la table khamsat_p1.users : ~4 rows (environ)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `ip`, `remember_token`, `created_at`, `updated_at`, `is_admin`) VALUES
	(1, 'soukfes', '125.10.0.1', NULL, '2020-05-30 02:37:01', '2020-05-30 02:37:01', 1),
	(8, 'soukfes', '127.022.0.1', NULL, '2020-05-31 12:13:30', '2020-05-31 12:13:30', 0),
	(9, 'soukfes', '1227.0.0.1', NULL, '2020-05-31 12:40:34', '2020-05-31 12:40:34', 1),
	(10, 'soukfes', '127.0.0.1', NULL, '2020-05-31 16:46:11', '2020-05-31 16:46:11', 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
